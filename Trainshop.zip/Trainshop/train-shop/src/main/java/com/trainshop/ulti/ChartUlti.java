package com.trainshop.ulti;

public interface ChartUlti {

}
