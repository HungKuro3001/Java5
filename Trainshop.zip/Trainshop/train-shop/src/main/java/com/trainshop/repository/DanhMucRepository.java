package com.trainshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.trainshop.entities.DanhMuc;

public interface DanhMucRepository extends JpaRepository<DanhMuc, Long>{

}
