package com.trainshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class TrainShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainShopApplication.class, args);
	}
}
