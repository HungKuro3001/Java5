package com.trainshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.trainshop.entities.HangSanXuat;

public interface HangSanXuatRepository extends JpaRepository<HangSanXuat, Long>{

}
